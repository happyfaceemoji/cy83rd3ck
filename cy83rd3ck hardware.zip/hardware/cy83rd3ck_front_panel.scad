// ============================================================
// cy83rd3ck — FRONT PANEL SHELL (concept, prototype)
// Overall: 94.6 x 151.51 x 1.5mm, corner radius 7mm
// Open this file in OpenSCAD (free, openscad.org) to view/export STL.
// All cutout positions derived from the front-panel diagram
// (cy83rd3ck_hardware_concept.pdf), 1 unit = 0.3534mm.
// ============================================================

W = 94.6;
H = 151.51;
T = 1.5;      // panel thickness
R = 7;        // corner radius
EXTRA = 4;    // extra height for cutout tools (through-cuts)

module rrect(w, h, r) {
    hull() {
        translate([r, r])           circle(r=r, $fn=48);
        translate([w-r, r])         circle(r=r, $fn=48);
        translate([r, h-r])         circle(r=r, $fn=48);
        translate([w-r, h-r])       circle(r=r, $fn=48);
    }
}

module panel() {
    linear_extrude(height=T) rrect(W, H, R);
}

module cut_rect(x, y, w, h) {
    translate([x, y, -EXTRA/2]) cube([w, h, T+EXTRA]);
}

module cut_circle(cx, cy, d) {
    translate([cx, cy, -EXTRA/2]) cylinder(d=d, h=T+EXTRA, $fn=48);
}

module front_panel() {
    difference() {
        panel();

        // ---- Display windows ----
        cut_rect(3.29, 78.61, 87, 52.5);     // SCREEN1 (4" 800x480 touch DSI, Waveshare 4-DSI-TOUCH-A / SKU 34354 active area)
        cut_rect(8.91, 24.43, 76.778, 19.178); // SCREEN2 (3.12" SSD1322 OLED active area)
        cut_rect(4.51, 4.11, 56.6, 14.1);    // SCREEN3 (2.3" 128x32 OLED)

        // ---- Record encoder + Play button (top row) ----
        cut_circle(68.11+3.5, 11.16+3.5, 7);  // RECORD encoder shaft, d=7mm
        cut_rect(73.89, 5.16, 12, 12);        // PLAY button

        // ---- TAP / NOTE / RPT / LP (6x6mm) ----
        cut_rect(63.80, 49.84, 6, 6);
        cut_rect(70.88, 49.84, 6, 6);
        cut_rect(77.97, 49.84, 6, 6);
        cut_rect(85.06, 49.84, 6, 6);

        // ---- Track buttons KICK/SNRE/HIHAT/BASS/LEAD (12x12mm) ----
        cut_rect(5.84,  57.63, 12, 12);
        cut_rect(22.80, 57.63, 12, 12);
        cut_rect(39.77, 57.63, 12, 12);
        cut_rect(56.38, 57.63, 12, 12);
        cut_rect(72.02, 57.63, 12, 12);

        // ---- Tab row x10 (4.5x4.5mm) ----
        for (i = [0:9]) {
            cut_rect(5.83 + i*8.726, 71.64, 4.5, 4.5);
        }

        // ---- Octave nav (<,>) + sound select x10 (6x6mm) ----
        oct_x = [3.71, 11.11, 18.50, 25.90, 33.30, 40.70, 48.10, 55.50, 62.89, 70.28, 77.69, 85.07];
        for (x = oct_x) {
            cut_rect(x, 129.77, 6, 6);
        }

        // ---- BEND / MOD slider slots (30mm travel x 4mm) ----
        cut_rect(2.98,  50.84, 30, 4);
        cut_rect(32.93, 50.84, 30, 4);

        // ---- Keyboard cutout (1 octave, FSR keybed pokes through) ----
        cut_rect(1.80, 137.69, 91.0, 12.05);

        // ---- Speaker grilles (bottom edge, simple slot vents) ----
        for (gx = [0:2]) {
            cut_rect(2.83 + gx*5,  H-4, 3, 3); // left grille, 3 slots
            cut_rect(75.77 + gx*5, H-4, 3, 3); // right grille, 3 slots
        }
    }
}

front_panel();

// ============================================================
// NOTES:
// - This is the FRONT PANEL only (1.5mm) — a good first print to
//   validate button/screen/keyboard alignment against real parts.
// - Side walls + back panel + internal standoffs are NOT modeled
//   yet; this is a flat test plate.
// - BEND/MOD slots assume the slider lever protrudes through a
//   30mm slot; verify against the actual ALPS RS30111 lever travel.
// - Track button & octave/sound cutouts are sized to the SWITCH
//   (12x12 / 6x6mm), not a larger keycap — add keycap clearance
//   if using oversized caps.
// - Keyboard cutout is a single rectangle; the FSR keybed assembly
//   sits behind it. Adjust once the donor keyboard is measured.
// ============================================================
